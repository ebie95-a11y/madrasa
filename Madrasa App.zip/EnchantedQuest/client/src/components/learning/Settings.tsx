import { useLearning } from "@/lib/stores/useLearning";
import { useAudio } from "@/lib/stores/useAudio";
import { ArrowLeft, Moon, Sun, Volume2, VolumeX, User, Baby } from "lucide-react";

interface SettingsProps {
  onNavigate: (screen: string) => void;
}

export function Settings({ onNavigate }: SettingsProps) {
  const { isAdultMode, setAdultMode, totalPoints, streak } = useLearning();
  const { isMuted, toggleMute } = useAudio();

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-sky-400 via-purple-400 to-pink-400'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              Settings
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Customize your learning
            </p>
          </div>
        </header>

        <div className="space-y-4">
          <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4`}>
            <h2 className={`text-lg font-semibold mb-4 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              Learning Mode
            </h2>
            
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setAdultMode(false)}
                className={`p-4 rounded-2xl flex flex-col items-center gap-2 transition-all ${
                  !isAdultMode 
                    ? 'bg-gradient-to-br from-pink-400 to-purple-500 ring-4 ring-white/50' 
                    : 'bg-white/10 hover:bg-white/20'
                }`}
              >
                <Baby className={`w-8 h-8 ${!isAdultMode ? 'text-white' : 'text-white/60'}`} />
                <span className={`font-semibold ${!isAdultMode ? 'text-white' : 'text-white/60'}`}>Kids Mode</span>
                <span className={`text-xs ${!isAdultMode ? 'text-white/80' : 'text-white/40'}`}>Colorful & fun</span>
              </button>
              
              <button
                onClick={() => setAdultMode(true)}
                className={`p-4 rounded-2xl flex flex-col items-center gap-2 transition-all ${
                  isAdultMode 
                    ? 'bg-gradient-to-br from-emerald-500 to-emerald-600 ring-4 ring-emerald-300/50' 
                    : 'bg-white/10 hover:bg-white/20'
                }`}
              >
                <User className={`w-8 h-8 ${isAdultMode ? 'text-white' : 'text-white/60'}`} />
                <span className={`font-semibold ${isAdultMode ? 'text-white' : 'text-white/60'}`}>Adult Mode</span>
                <span className={`text-xs ${isAdultMode ? 'text-white/80' : 'text-white/40'}`}>Simple & focused</span>
              </button>
            </div>
          </div>

          <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4`}>
            <h2 className={`text-lg font-semibold mb-4 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              Sound Settings
            </h2>
            
            <button
              onClick={toggleMute}
              className={`w-full p-4 rounded-xl flex items-center justify-between ${
                isAdultMode ? 'bg-emerald-700/50 hover:bg-emerald-700' : 'bg-white/10 hover:bg-white/20'
              } transition-all`}
            >
              <div className="flex items-center gap-3">
                {isMuted ? (
                  <VolumeX className={`w-6 h-6 ${isAdultMode ? 'text-emerald-300' : 'text-white'}`} />
                ) : (
                  <Volume2 className={`w-6 h-6 ${isAdultMode ? 'text-emerald-300' : 'text-white'}`} />
                )}
                <span className={`font-medium ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
                  Sound Effects
                </span>
              </div>
              <div className={`w-12 h-6 rounded-full ${isMuted ? 'bg-gray-500' : (isAdultMode ? 'bg-emerald-500' : 'bg-green-500')} relative transition-colors`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isMuted ? 'left-1' : 'left-7'}`} />
              </div>
            </button>
          </div>

          <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4`}>
            <h2 className={`text-lg font-semibold mb-4 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              Your Stats
            </h2>
            
            <div className="grid grid-cols-2 gap-3">
              <div className={`p-4 rounded-xl ${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/10'} text-center`}>
                <p className={`text-2xl font-bold ${isAdultMode ? 'text-yellow-400' : 'text-yellow-300'}`}>
                  {totalPoints}
                </p>
                <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Total Points</p>
              </div>
              <div className={`p-4 rounded-xl ${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/10'} text-center`}>
                <p className={`text-2xl font-bold ${isAdultMode ? 'text-orange-400' : 'text-orange-300'}`}>
                  {streak} 🔥
                </p>
                <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Day Streak</p>
              </div>
            </div>
          </div>

          <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4`}>
            <h2 className={`text-lg font-semibold mb-2 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              About
            </h2>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Madrasa tul Nurul Mubeen
            </p>
            <p className={`text-xs mt-2 ${isAdultMode ? 'text-emerald-400' : 'text-white/60'}`}>
              A learning app dedicated to teaching Qur'an reading for children and beginners.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
