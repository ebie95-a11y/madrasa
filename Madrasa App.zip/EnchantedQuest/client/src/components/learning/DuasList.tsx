import { useState } from "react";
import { useLearning } from "@/lib/stores/useLearning";
import { ArrowLeft, Play, ChevronDown, ChevronUp } from "lucide-react";

interface DuasListProps {
  onNavigate: (screen: string) => void;
}

interface Dua {
  id: number;
  title: string;
  titleArabic: string;
  arabic: string;
  transliteration: string;
  translation: string;
  category: string;
}

const duas: Dua[] = [
  {
    id: 1,
    title: "Before Eating",
    titleArabic: "دعاء قبل الطعام",
    arabic: "بِسْمِ اللَّهِ",
    transliteration: "Bismillah",
    translation: "In the name of Allah",
    category: "daily"
  },
  {
    id: 2,
    title: "After Eating",
    titleArabic: "دعاء بعد الطعام",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مُسْلِمِينَ",
    transliteration: "Alhamdu lillahil-ladhi at'amana wa saqana wa ja'alana muslimeen",
    translation: "All praise is for Allah who fed us and gave us drink and made us Muslims",
    category: "daily"
  },
  {
    id: 3,
    title: "Before Sleeping",
    titleArabic: "دعاء قبل النوم",
    arabic: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا",
    transliteration: "Bismika Allahumma amutu wa ahya",
    translation: "In Your name O Allah, I die and I live",
    category: "daily"
  },
  {
    id: 4,
    title: "Upon Waking Up",
    titleArabic: "دعاء الاستيقاظ",
    arabic: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ",
    transliteration: "Alhamdu lillahil-ladhi ahyana ba'da ma amatana wa ilayhin-nushur",
    translation: "All praise is for Allah who gave us life after having taken it from us and unto Him is the resurrection",
    category: "daily"
  },
  {
    id: 5,
    title: "Entering the Bathroom",
    titleArabic: "دعاء دخول الخلاء",
    arabic: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ",
    transliteration: "Allahumma inni a'udhu bika minal-khubuthi wal-khaba'ith",
    translation: "O Allah, I seek refuge in You from the male and female evil spirits",
    category: "daily"
  },
  {
    id: 6,
    title: "Leaving the Bathroom",
    titleArabic: "دعاء الخروج من الخلاء",
    arabic: "غُفْرَانَكَ",
    transliteration: "Ghufranaka",
    translation: "I seek Your forgiveness",
    category: "daily"
  },
  {
    id: 7,
    title: "Entering the Home",
    titleArabic: "دعاء دخول المنزل",
    arabic: "بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى رَبِّنَا تَوَكَّلْنَا",
    transliteration: "Bismillahi walajna, wa bismillahi kharajna, wa 'ala Rabbina tawakkalna",
    translation: "In the name of Allah we enter, and in the name of Allah we leave, and upon our Lord we rely",
    category: "daily"
  },
  {
    id: 8,
    title: "Before Starting Work",
    titleArabic: "دعاء بدء العمل",
    arabic: "بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ",
    transliteration: "Bismillahi tawakkaltu 'alallah",
    translation: "In the name of Allah, I place my trust in Allah",
    category: "daily"
  },
];

export function DuasList({ onNavigate }: DuasListProps) {
  const { isAdultMode, addPoints } = useLearning();
  const [expandedDua, setExpandedDua] = useState<number | null>(null);

  const toggleDua = (duaId: number) => {
    if (expandedDua === duaId) {
      setExpandedDua(null);
    } else {
      setExpandedDua(duaId);
      addPoints(2);
    }
  };

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-purple-400 via-pink-400 to-red-400'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              Daily Duas
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              الأدعية اليومية
            </p>
          </div>
        </header>

        <div className="space-y-3">
          {duas.map((dua) => (
            <div
              key={dua.id}
              className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl overflow-hidden transition-all`}
            >
              <button
                onClick={() => toggleDua(dua.id)}
                className="w-full p-4 flex items-center justify-between"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl ${isAdultMode ? 'bg-emerald-700' : 'bg-white/20'} flex items-center justify-center`}>
                    <span className="text-xl">🤲</span>
                  </div>
                  <div className="text-left">
                    <p className={`font-semibold ${isAdultMode ? 'text-white' : 'text-white'}`}>{dua.title}</p>
                    <p className={`text-sm font-arabic ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>{dua.titleArabic}</p>
                  </div>
                </div>
                {expandedDua === dua.id ? (
                  <ChevronUp className={`w-5 h-5 ${isAdultMode ? 'text-emerald-300' : 'text-white'}`} />
                ) : (
                  <ChevronDown className={`w-5 h-5 ${isAdultMode ? 'text-emerald-300' : 'text-white'}`} />
                )}
              </button>
              
              {expandedDua === dua.id && (
                <div className={`px-4 pb-4 border-t ${isAdultMode ? 'border-emerald-700' : 'border-white/20'}`}>
                  <div className="pt-4 text-center">
                    <p className={`text-2xl font-arabic leading-loose mb-3 ${isAdultMode ? 'text-white' : 'text-white'}`} dir="rtl">
                      {dua.arabic}
                    </p>
                    <p className={`text-base italic mb-2 ${isAdultMode ? 'text-emerald-200' : 'text-white/90'}`}>
                      {dua.transliteration}
                    </p>
                    <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/70'}`}>
                      {dua.translation}
                    </p>
                    
                    <button className={`mt-4 px-6 py-2 rounded-full ${isAdultMode ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-white/30 hover:bg-white/40'} flex items-center gap-2 mx-auto transition-colors`}>
                      <Play className={`w-4 h-4 ${isAdultMode ? 'text-white' : 'text-white'}`} />
                      <span className={`${isAdultMode ? 'text-white' : 'text-white'}`}>Play Audio</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className={`mt-6 ${isAdultMode ? 'bg-emerald-800/50' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4 text-center`}>
          <p className={`text-sm ${isAdultMode ? 'text-emerald-200' : 'text-white/80'}`}>
            💡 Tap on any dua to expand and learn the full text with translation
          </p>
        </div>
      </div>
    </div>
  );
}
