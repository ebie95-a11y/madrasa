import { useState, useEffect } from "react";
import { useLearning, Surah } from "@/lib/stores/useLearning";
import { ArrowLeft, Play, Pause, Volume2, Eye, EyeOff, ChevronLeft, ChevronRight } from "lucide-react";

interface SurahReaderProps {
  surah: Surah;
  onNavigate: (screen: string) => void;
}

interface VerseData {
  number: number;
  arabic: string;
  transliteration: string;
  translation: string;
}

const surahVerses: Record<number, VerseData[]> = {
  1: [
    { number: 1, arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", transliteration: "Bismillahir Rahmanir Raheem", translation: "In the name of Allah, the Most Gracious, the Most Merciful" },
    { number: 2, arabic: "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", transliteration: "Alhamdu lillahi Rabbil 'aalameen", translation: "All praise is due to Allah, Lord of all the worlds" },
    { number: 3, arabic: "الرَّحْمَٰنِ الرَّحِيمِ", transliteration: "Ar-Rahmanir Raheem", translation: "The Most Gracious, the Most Merciful" },
    { number: 4, arabic: "مَالِكِ يَوْمِ الدِّينِ", transliteration: "Maliki yawmid-deen", translation: "Master of the Day of Judgment" },
    { number: 5, arabic: "إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ", transliteration: "Iyyaka na'budu wa iyyaka nasta'een", translation: "You alone we worship, and You alone we ask for help" },
    { number: 6, arabic: "اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ", transliteration: "Ihdinas siratal mustaqeem", translation: "Guide us on the Straight Path" },
    { number: 7, arabic: "صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ", transliteration: "Siratal ladhina an'amta 'alayhim, ghayril maghdubi 'alayhim wa lad-daalleen", translation: "The path of those You have blessed, not of those who earned Your anger, nor of those who went astray" },
  ],
  112: [
    { number: 1, arabic: "قُلْ هُوَ اللَّهُ أَحَدٌ", transliteration: "Qul huwal-lahu ahad", translation: "Say, He is Allah, the One" },
    { number: 2, arabic: "اللَّهُ الصَّمَدُ", transliteration: "Allahus-samad", translation: "Allah, the Eternal Refuge" },
    { number: 3, arabic: "لَمْ يَلِدْ وَلَمْ يُولَدْ", transliteration: "Lam yalid wa lam yulad", translation: "He neither begets nor is born" },
    { number: 4, arabic: "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", transliteration: "Wa lam yakul-lahu kufuwan ahad", translation: "Nor is there any equivalent to Him" },
  ],
  113: [
    { number: 1, arabic: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", transliteration: "Qul a'udhu bi rabbil-falaq", translation: "Say, I seek refuge in the Lord of daybreak" },
    { number: 2, arabic: "مِن شَرِّ مَا خَلَقَ", transliteration: "Min sharri ma khalaq", translation: "From the evil of that which He created" },
    { number: 3, arabic: "وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ", transliteration: "Wa min sharri ghasiqin idha waqab", translation: "And from the evil of darkness when it settles" },
    { number: 4, arabic: "وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ", transliteration: "Wa min sharrin-naffathati fil-'uqad", translation: "And from the evil of those who blow on knots" },
    { number: 5, arabic: "وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ", transliteration: "Wa min sharri hasidin idha hasad", translation: "And from the evil of an envier when he envies" },
  ],
  114: [
    { number: 1, arabic: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", transliteration: "Qul a'udhu bi rabbin-nas", translation: "Say, I seek refuge in the Lord of mankind" },
    { number: 2, arabic: "مَلِكِ النَّاسِ", transliteration: "Malikin-nas", translation: "The King of mankind" },
    { number: 3, arabic: "إِلَٰهِ النَّاسِ", transliteration: "Ilahin-nas", translation: "The God of mankind" },
    { number: 4, arabic: "مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ", transliteration: "Min sharril-waswasil-khannas", translation: "From the evil of the retreating whisperer" },
    { number: 5, arabic: "الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ", transliteration: "Alladhi yuwaswisu fi sudurin-nas", translation: "Who whispers in the breasts of mankind" },
    { number: 6, arabic: "مِنَ الْجِنَّةِ وَالنَّاسِ", transliteration: "Minal-jinnati wan-nas", translation: "From among the jinn and mankind" },
  ],
  108: [
    { number: 1, arabic: "إِنَّا أَعْطَيْنَاكَ الْكَوْثَرَ", transliteration: "Inna a'taynakal-kawthar", translation: "Indeed, We have granted you Al-Kawthar" },
    { number: 2, arabic: "فَصَلِّ لِرَبِّكَ وَانْحَرْ", transliteration: "Fasalli li-rabbika wanhar", translation: "So pray to your Lord and sacrifice" },
    { number: 3, arabic: "إِنَّ شَانِئَكَ هُوَ الْأَبْتَرُ", transliteration: "Inna shani'aka huwal-abtar", translation: "Indeed, your enemy is the one cut off" },
  ],
  110: [
    { number: 1, arabic: "إِذَا جَاءَ نَصْرُ اللَّهِ وَالْفَتْحُ", transliteration: "Idha ja'a nasrul-lahi wal-fath", translation: "When the victory of Allah has come and the conquest" },
    { number: 2, arabic: "وَرَأَيْتَ النَّاسَ يَدْخُلُونَ فِي دِينِ اللَّهِ أَفْوَاجًا", transliteration: "Wa ra'aytan-nasa yadkhuluna fi dinil-lahi afwaja", translation: "And you see the people entering into the religion of Allah in multitudes" },
    { number: 3, arabic: "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُ ۚ إِنَّهُ كَانَ تَوَّابًا", transliteration: "Fasabbih bihamdi rabbika wastaghfirh, innahu kana tawwaba", translation: "Then exalt with praise of your Lord and ask forgiveness of Him. Indeed, He is ever accepting of repentance" },
  ],
  111: [
    { number: 1, arabic: "تَبَّتْ يَدَا أَبِي لَهَبٍ وَتَبَّ", transliteration: "Tabbat yada abi lahabin wa tabb", translation: "May the hands of Abu Lahab be ruined, and ruined is he" },
    { number: 2, arabic: "مَا أَغْنَىٰ عَنْهُ مَالُهُ وَمَا كَسَبَ", transliteration: "Ma aghna 'anhu maluhu wa ma kasab", translation: "His wealth will not avail him or that which he gained" },
    { number: 3, arabic: "سَيَصْلَىٰ نَارًا ذَاتَ لَهَبٍ", transliteration: "Sayasla naran dhata lahab", translation: "He will burn in a Fire of blazing flame" },
    { number: 4, arabic: "وَامْرَأَتُهُ حَمَّالَةَ الْحَطَبِ", transliteration: "Wamra'atuhu hammalatal-hatab", translation: "And his wife, the carrier of firewood" },
    { number: 5, arabic: "فِي جِيدِهَا حَبْلٌ مِّن مَّسَدٍ", transliteration: "Fi jidiha hablum mim-masad", translation: "Around her neck is a rope of palm fiber" },
  ],
  109: [
    { number: 1, arabic: "قُلْ يَا أَيُّهَا الْكَافِرُونَ", transliteration: "Qul ya ayyuhal-kafirun", translation: "Say, O disbelievers" },
    { number: 2, arabic: "لَا أَعْبُدُ مَا تَعْبُدُونَ", transliteration: "La a'budu ma ta'budun", translation: "I do not worship what you worship" },
    { number: 3, arabic: "وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ", transliteration: "Wa la antum 'abiduna ma a'bud", translation: "Nor are you worshippers of what I worship" },
    { number: 4, arabic: "وَلَا أَنَا عَابِدٌ مَّا عَبَدتُّمْ", transliteration: "Wa la ana 'abidum ma 'abadtum", translation: "Nor will I be a worshipper of what you worship" },
    { number: 5, arabic: "وَلَا أَنتُمْ عَابِدُونَ مَا أَعْبُدُ", transliteration: "Wa la antum 'abiduna ma a'bud", translation: "Nor will you be worshippers of what I worship" },
    { number: 6, arabic: "لَكُمْ دِينُكُمْ وَلِيَ دِينِ", transliteration: "Lakum dinukum waliya din", translation: "For you is your religion, and for me is my religion" },
  ],
};

export function SurahReader({ surah, onNavigate }: SurahReaderProps) {
  const { isAdultMode, currentVerse, setCurrentVerse, showTajweed, toggleTajweed, isPlaying, togglePlaying, addPoints } = useLearning();
  const [showTranslation, setShowTranslation] = useState(true);
  
  const verses = surahVerses[surah.number] || [];
  const currentVerseData = verses[currentVerse - 1];

  const goToNextVerse = () => {
    if (currentVerse < verses.length) {
      setCurrentVerse(currentVerse + 1);
      addPoints(5);
    }
  };

  const goToPrevVerse = () => {
    if (currentVerse > 1) {
      setCurrentVerse(currentVerse - 1);
    }
  };

  useEffect(() => {
    setCurrentVerse(1);
  }, [surah, setCurrentVerse]);

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-indigo-500 via-purple-500 to-pink-500'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('surahs')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div className="text-center">
            <h1 className={`text-xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              {surah.nameTransliteration}
            </h1>
            <p className={`text-2xl font-arabic ${isAdultMode ? 'text-emerald-200' : 'text-white/90'}`}>
              {surah.nameArabic}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowTranslation(!showTranslation)}
              className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
            >
              {showTranslation ? <Eye size={20} /> : <EyeOff size={20} />}
            </button>
          </div>
        </header>

        <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-2 mb-4`}>
          <div className="flex items-center justify-between">
            <span className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Verse {currentVerse} of {verses.length}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={toggleTajweed}
                className={`px-3 py-1 rounded-full text-xs ${showTajweed ? (isAdultMode ? 'bg-emerald-600 text-white' : 'bg-green-500 text-white') : (isAdultMode ? 'bg-emerald-900 text-emerald-400' : 'bg-white/20 text-white/60')}`}
              >
                Tajweed
              </button>
            </div>
          </div>
          <div className="w-full bg-white/20 rounded-full h-2 mt-2">
            <div
              className={`${isAdultMode ? 'bg-emerald-400' : 'bg-gradient-to-r from-green-400 to-emerald-500'} h-2 rounded-full transition-all`}
              style={{ width: `${(currentVerse / verses.length) * 100}%` }}
            />
          </div>
        </div>

        {currentVerseData && (
          <div className={`${isAdultMode ? 'bg-emerald-800/50' : 'bg-white/30'} backdrop-blur-sm rounded-3xl p-6 mb-6`}>
            <div className="text-center mb-6">
              <div className={`inline-block px-4 py-2 rounded-full ${isAdultMode ? 'bg-emerald-700' : 'bg-white/20'} mb-4`}>
                <span className={`text-lg ${isAdultMode ? 'text-emerald-200' : 'text-white'}`}>
                  Ayah {currentVerseData.number}
                </span>
              </div>
              
              <p className={`text-4xl leading-loose font-arabic mb-6 ${isAdultMode ? 'text-white' : 'text-white'}`} dir="rtl">
                {currentVerseData.arabic}
              </p>
              
              <div className={`border-t ${isAdultMode ? 'border-emerald-700' : 'border-white/20'} pt-4 mt-4`}>
                <p className={`text-lg italic mb-2 ${isAdultMode ? 'text-emerald-200' : 'text-white/90'}`}>
                  {currentVerseData.transliteration}
                </p>
                
                {showTranslation && (
                  <p className={`text-base ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                    {currentVerseData.translation}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center justify-center gap-4">
              <button
                onClick={goToPrevVerse}
                disabled={currentVerse === 1}
                className={`p-3 rounded-full ${currentVerse === 1 ? 'opacity-50' : ''} ${isAdultMode ? 'bg-emerald-700 text-white' : 'bg-white/20 text-white'}`}
              >
                <ChevronLeft size={24} />
              </button>
              
              <button
                onClick={togglePlaying}
                className={`p-4 rounded-full ${isAdultMode ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-gradient-to-br from-green-400 to-emerald-500 hover:from-green-300 hover:to-emerald-400'} text-white shadow-lg transition-all`}
              >
                {isPlaying ? <Pause size={28} /> : <Play size={28} />}
              </button>
              
              <button
                onClick={goToNextVerse}
                disabled={currentVerse === verses.length}
                className={`p-3 rounded-full ${currentVerse === verses.length ? 'opacity-50' : ''} ${isAdultMode ? 'bg-emerald-700 text-white' : 'bg-white/20 text-white'}`}
              >
                <ChevronRight size={24} />
              </button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap justify-center gap-2">
          {verses.map((verse, index) => (
            <button
              key={verse.number}
              onClick={() => setCurrentVerse(index + 1)}
              className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${
                currentVerse === index + 1
                  ? (isAdultMode ? 'bg-emerald-500 text-white' : 'bg-white text-purple-600')
                  : index + 1 < currentVerse
                    ? (isAdultMode ? 'bg-emerald-700 text-emerald-200' : 'bg-white/40 text-white')
                    : (isAdultMode ? 'bg-emerald-800/50 text-emerald-400' : 'bg-white/20 text-white/70')
              }`}
            >
              {verse.number}
            </button>
          ))}
        </div>

        {currentVerse === verses.length && (
          <div className={`mt-6 ${isAdultMode ? 'bg-emerald-700' : 'bg-gradient-to-r from-yellow-400 to-orange-400'} rounded-2xl p-4 text-center`}>
            <span className="text-3xl mb-2 block">🎉</span>
            <p className="text-white font-semibold">Masha'Allah! You completed {surah.nameTransliteration}!</p>
            <p className="text-white/80 text-sm mt-1">+50 points earned</p>
          </div>
        )}
      </div>
    </div>
  );
}
