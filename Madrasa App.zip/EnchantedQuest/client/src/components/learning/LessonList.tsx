import { useLearning, Lesson } from "@/lib/stores/useLearning";
import { ArrowLeft, Check, Lock, Star } from "lucide-react";

interface LessonListProps {
  onNavigate: (screen: string) => void;
  onSelectLesson: (lesson: Lesson) => void;
}

export function LessonList({ onNavigate, onSelectLesson }: LessonListProps) {
  const { lessons, progress, isAdultMode } = useLearning();

  const getLessonStatus = (lesson: Lesson, index: number) => {
    const lessonProgress = progress.get(lesson.id);
    if (lessonProgress?.completed) return 'completed';
    if (index === 0) return 'available';
    const prevLesson = lessons[index - 1];
    const prevProgress = progress.get(prevLesson.id);
    return prevProgress?.completed ? 'available' : 'locked';
  };

  const categoryColors: Record<string, string> = {
    basics: isAdultMode ? 'from-emerald-600 to-emerald-700' : 'from-green-400 to-emerald-500',
    surah: isAdultMode ? 'from-blue-600 to-blue-700' : 'from-blue-400 to-indigo-500',
    tajweed: isAdultMode ? 'from-purple-600 to-purple-700' : 'from-purple-400 to-pink-500',
  };

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-sky-400 via-purple-400 to-pink-400'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              Lessons
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Learn step by step
            </p>
          </div>
        </header>

        <div className="space-y-4">
          {lessons.map((lesson, index) => {
            const status = getLessonStatus(lesson, index);
            const lessonProgress = progress.get(lesson.id);
            
            return (
              <button
                key={lesson.id}
                onClick={() => status !== 'locked' && onSelectLesson(lesson)}
                disabled={status === 'locked'}
                className={`w-full ${status === 'locked' ? 'opacity-60' : ''}`}
              >
                <div className={`bg-gradient-to-r ${categoryColors[lesson.category] || categoryColors.basics} rounded-2xl p-4 flex items-center gap-4 shadow-lg transition-all ${status !== 'locked' ? 'hover:scale-[1.02]' : ''}`}>
                  <div className={`w-14 h-14 rounded-2xl ${status === 'completed' ? 'bg-green-500' : status === 'locked' ? 'bg-gray-500' : 'bg-white/20'} flex items-center justify-center`}>
                    {status === 'completed' ? (
                      <Check className="w-8 h-8 text-white" />
                    ) : status === 'locked' ? (
                      <Lock className="w-6 h-6 text-white" />
                    ) : (
                      <span className="text-2xl font-bold text-white">{index + 1}</span>
                    )}
                  </div>
                  
                  <div className="flex-1 text-left">
                    <p className="text-white font-semibold text-lg">{lesson.title}</p>
                    {lesson.titleArabic && (
                      <p className="text-white/80 text-right font-arabic text-lg">{lesson.titleArabic}</p>
                    )}
                    <p className="text-white/70 text-sm">{lesson.description}</p>
                  </div>
                  
                  <div className="flex flex-col items-center gap-1">
                    {lessonProgress && lessonProgress.masteryLevel > 0 && (
                      <div className="flex items-center gap-1">
                        {Array.from({ length: Math.min(lessonProgress.masteryLevel, 3) }).map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                        ))}
                      </div>
                    )}
                    <div className={`px-2 py-1 rounded-full ${
                      lesson.difficulty === 1 ? 'bg-green-500/50' :
                      lesson.difficulty === 2 ? 'bg-yellow-500/50' : 'bg-red-500/50'
                    }`}>
                      <span className="text-white text-xs">
                        {lesson.difficulty === 1 ? 'Easy' : lesson.difficulty === 2 ? 'Medium' : 'Hard'}
                      </span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {!isAdultMode && (
          <div className="mt-6 bg-white/20 backdrop-blur-sm rounded-2xl p-4 text-center">
            <p className="text-white font-semibold">💡 Tip</p>
            <p className="text-white/80 text-sm">Complete lessons in order to unlock new ones!</p>
          </div>
        )}
      </div>
    </div>
  );
}
