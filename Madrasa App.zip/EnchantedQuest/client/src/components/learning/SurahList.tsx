import { useLearning, Surah } from "@/lib/stores/useLearning";
import { ArrowLeft, Star } from "lucide-react";

interface SurahListProps {
  onNavigate: (screen: string) => void;
  onSelectSurah: (surah: Surah) => void;
}

export function SurahList({ onNavigate, onSelectSurah }: SurahListProps) {
  const { surahs, isAdultMode } = useLearning();

  const getDifficultyStars = (difficulty: number) => {
    return Array.from({ length: difficulty }).map((_, i) => (
      <Star key={i} className="w-3 h-3 text-yellow-400 fill-yellow-400" />
    ));
  };

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-sky-400 via-purple-400 to-pink-400'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              Short Surahs
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Select a Surah to read
            </p>
          </div>
        </header>

        <div className="space-y-3">
          {surahs.map((surah) => (
            <button
              key={surah.id}
              onClick={() => onSelectSurah(surah)}
              className="w-full"
            >
              <div className={`${isAdultMode ? 'bg-emerald-800/70 hover:bg-emerald-700/70' : 'bg-white/20 hover:bg-white/30'} backdrop-blur-sm rounded-2xl p-4 flex items-center gap-4 transition-all hover:scale-[1.02] shadow-lg`}>
                <div className={`w-12 h-12 rounded-xl ${isAdultMode ? 'bg-emerald-600' : 'bg-gradient-to-br from-indigo-500 to-purple-600'} flex items-center justify-center`}>
                  <span className="text-white font-bold">{surah.number}</span>
                </div>
                
                <div className="flex-1 text-left">
                  <div className="flex items-center justify-between">
                    <p className={`font-semibold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                      {surah.nameTransliteration}
                    </p>
                    <p className={`text-2xl font-arabic ${isAdultMode ? 'text-emerald-200' : 'text-white'}`}>
                      {surah.nameArabic}
                    </p>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/70'}`}>
                      {surah.nameEnglish} • {surah.versesCount} verses
                    </p>
                    <div className="flex items-center gap-0.5">
                      {getDifficultyStars(surah.difficulty)}
                    </div>
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        <div className={`mt-6 ${isAdultMode ? 'bg-emerald-800/50' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4 text-center`}>
          <p className={`text-sm ${isAdultMode ? 'text-emerald-200' : 'text-white/80'}`}>
            📖 Tap on any Surah to start learning with word-by-word guidance
          </p>
        </div>
      </div>
    </div>
  );
}
