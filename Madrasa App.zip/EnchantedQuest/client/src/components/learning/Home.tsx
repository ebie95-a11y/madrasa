import { useLearning } from "@/lib/stores/useLearning";
import { Star, Book, Award, Settings } from "lucide-react";

interface HomeProps {
  onNavigate: (screen: string) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const { totalPoints, streak, isAdultMode, lessons, progress } = useLearning();
  
  const completedLessons = Array.from(progress.values()).filter(p => p.completed).length;
  const totalLessons = lessons.length;
  const progressPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-sky-400 via-purple-400 to-pink-400'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex justify-between items-center mb-6">
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              مدرسة نور المبين
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Madrasa Nurul Mubeen
            </p>
          </div>
          <button
            onClick={() => onNavigate('settings')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <Settings size={24} />
          </button>
        </header>

        <div className={`${isAdultMode ? 'bg-emerald-800/50' : 'bg-white/20'} backdrop-blur-sm rounded-3xl p-6 mb-6`}>
          <div className="flex items-center justify-center mb-4">
            <div className={`w-24 h-24 rounded-full ${isAdultMode ? 'bg-emerald-700' : 'bg-gradient-to-br from-yellow-300 to-orange-400'} flex items-center justify-center shadow-lg`}>
              <span className="text-4xl">📖</span>
            </div>
          </div>
          
          <div className="text-center mb-4">
            <p className={`text-lg ${isAdultMode ? 'text-emerald-200' : 'text-white'}`}>
              {isAdultMode ? 'Welcome back!' : 'Assalamu Alaikum!'}
            </p>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              {isAdultMode ? 'Continue your Qur\'an journey' : 'Ready to learn today?'}
            </p>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/30'} rounded-2xl p-3 text-center`}>
              <Star className={`w-6 h-6 mx-auto mb-1 ${isAdultMode ? 'text-yellow-400' : 'text-yellow-300'}`} />
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>{totalPoints}</p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Points</p>
            </div>
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/30'} rounded-2xl p-3 text-center`}>
              <span className="text-2xl">🔥</span>
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>{streak}</p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Streak</p>
            </div>
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/30'} rounded-2xl p-3 text-center`}>
              <Award className={`w-6 h-6 mx-auto mb-1 ${isAdultMode ? 'text-purple-400' : 'text-purple-300'}`} />
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>{progressPercent}%</p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Progress</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6">
          <button
            onClick={() => onNavigate('lessons')}
            className={`${isAdultMode ? 'bg-emerald-700 hover:bg-emerald-600' : 'bg-gradient-to-br from-green-400 to-emerald-500 hover:from-green-300 hover:to-emerald-400'} rounded-3xl p-6 text-center transition-all transform hover:scale-105 shadow-lg`}
          >
            <div className="text-4xl mb-2">📚</div>
            <p className="text-white font-semibold">Lessons</p>
            <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Learn step by step</p>
          </button>
          
          <button
            onClick={() => onNavigate('surahs')}
            className={`${isAdultMode ? 'bg-emerald-700 hover:bg-emerald-600' : 'bg-gradient-to-br from-blue-400 to-indigo-500 hover:from-blue-300 hover:to-indigo-400'} rounded-3xl p-6 text-center transition-all transform hover:scale-105 shadow-lg`}
          >
            <div className="text-4xl mb-2">📖</div>
            <p className="text-white font-semibold">Surahs</p>
            <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Read & memorize</p>
          </button>
          
          <button
            onClick={() => onNavigate('duas')}
            className={`${isAdultMode ? 'bg-emerald-700 hover:bg-emerald-600' : 'bg-gradient-to-br from-purple-400 to-pink-500 hover:from-purple-300 hover:to-pink-400'} rounded-3xl p-6 text-center transition-all transform hover:scale-105 shadow-lg`}
          >
            <div className="text-4xl mb-2">🤲</div>
            <p className="text-white font-semibold">Duas</p>
            <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Daily prayers</p>
          </button>
          
          <button
            onClick={() => onNavigate('progress')}
            className={`${isAdultMode ? 'bg-emerald-700 hover:bg-emerald-600' : 'bg-gradient-to-br from-orange-400 to-red-500 hover:from-orange-300 hover:to-red-400'} rounded-3xl p-6 text-center transition-all transform hover:scale-105 shadow-lg`}
          >
            <div className="text-4xl mb-2">📊</div>
            <p className="text-white font-semibold">Progress</p>
            <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>Track learning</p>
          </button>
        </div>

        {!isAdultMode && (
          <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-3xl p-4 flex items-center gap-4 shadow-lg">
            <div className="text-4xl">⭐</div>
            <div className="flex-1">
              <p className="text-white font-semibold">Keep up the great work!</p>
              <p className="text-white/80 text-sm">Practice daily to earn more stars</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
