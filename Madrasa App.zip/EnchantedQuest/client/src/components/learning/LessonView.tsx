import { useState } from "react";
import { useLearning, Lesson } from "@/lib/stores/useLearning";
import { ArrowLeft, Check, ChevronRight, Play, Star } from "lucide-react";

interface LessonViewProps {
  lesson: Lesson;
  onNavigate: (screen: string) => void;
  onComplete: () => void;
}

interface LessonStep {
  type: "text" | "arabic" | "practice" | "quiz";
  content: string;
  arabic?: string;
  transliteration?: string;
  options?: string[];
  correctAnswer?: number;
}

const lessonContent: Record<number, LessonStep[]> = {
  1: [
    { type: "text", content: "Welcome! Let's learn the Arabic alphabet. The Arabic alphabet has 28 letters." },
    { type: "arabic", content: "This is Alif - the first letter:", arabic: "ا", transliteration: "Alif" },
    { type: "arabic", content: "This is Ba - the second letter:", arabic: "ب", transliteration: "Ba" },
    { type: "arabic", content: "This is Ta - the third letter:", arabic: "ت", transliteration: "Ta" },
    { type: "arabic", content: "This is Tha - the fourth letter:", arabic: "ث", transliteration: "Tha" },
    { type: "practice", content: "Practice saying each letter out loud!" },
    { type: "quiz", content: "What is the name of this letter: ب", options: ["Alif", "Ba", "Ta", "Tha"], correctAnswer: 1 },
  ],
  2: [
    { type: "text", content: "Short vowels are small marks that tell us how to pronounce letters." },
    { type: "arabic", content: "Fatha - makes an 'a' sound:", arabic: "بَ", transliteration: "Ba" },
    { type: "arabic", content: "Kasra - makes an 'i' sound:", arabic: "بِ", transliteration: "Bi" },
    { type: "arabic", content: "Damma - makes an 'u' sound:", arabic: "بُ", transliteration: "Bu" },
    { type: "practice", content: "Try pronouncing: Ba, Bi, Bu" },
    { type: "quiz", content: "Which vowel makes the 'i' sound?", options: ["Fatha", "Kasra", "Damma"], correctAnswer: 1 },
  ],
  3: [
    { type: "text", content: "Long vowels extend the sound of short vowels." },
    { type: "arabic", content: "Alif extends Fatha:", arabic: "بَا", transliteration: "Baa" },
    { type: "arabic", content: "Ya extends Kasra:", arabic: "بِي", transliteration: "Bee" },
    { type: "arabic", content: "Waw extends Damma:", arabic: "بُو", transliteration: "Boo" },
    { type: "practice", content: "Practice: Baa, Bee, Boo" },
  ],
  4: [
    { type: "text", content: "Surah Al-Fatiha is the opening chapter of the Quran. It has 7 verses." },
    { type: "arabic", content: "Start with Bismillah:", arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ", transliteration: "Bismillahir Rahmanir Raheem" },
    { type: "practice", content: "Listen and repeat each word carefully." },
    { type: "text", content: "Continue to the Surah reader to learn all verses!" },
  ],
  5: [
    { type: "text", content: "Surah Al-Ikhlas teaches us about the oneness of Allah. It has 4 verses." },
    { type: "arabic", content: "First verse:", arabic: "قُلْ هُوَ اللَّهُ أَحَدٌ", transliteration: "Qul huwal-lahu ahad" },
    { type: "practice", content: "This Surah is equal to one-third of the Quran in reward!" },
  ],
  6: [
    { type: "text", content: "Surah Al-Falaq is a protection surah. It has 5 verses." },
    { type: "arabic", content: "Begin with:", arabic: "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", transliteration: "Qul a'udhu bi rabbil-falaq" },
    { type: "practice", content: "Recite this surah for protection from evil." },
  ],
  7: [
    { type: "text", content: "Surah An-Nas is also a protection surah. It has 6 verses." },
    { type: "arabic", content: "Begin with:", arabic: "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", transliteration: "Qul a'udhu bi rabbin-nas" },
    { type: "practice", content: "Recite this surah along with Al-Falaq for complete protection." },
  ],
};

export function LessonView({ lesson, onNavigate, onComplete }: LessonViewProps) {
  const { isAdultMode, addPoints, completeLesson } = useLearning();
  const [currentStep, setCurrentStep] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  
  const steps = lessonContent[lesson.id] || [
    { type: "text", content: "This lesson content is coming soon!" },
  ];
  
  const step = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;

  const handleNext = () => {
    if (step.type === "quiz" && selectedAnswer === null) return;
    
    if (isLastStep) {
      completeLesson(lesson.id);
      addPoints(25);
      onComplete();
    } else {
      setCurrentStep(currentStep + 1);
      setSelectedAnswer(null);
      setIsCorrect(null);
      addPoints(5);
    }
  };

  const handleAnswer = (index: number) => {
    setSelectedAnswer(index);
    setIsCorrect(index === step.correctAnswer);
    if (index === step.correctAnswer) {
      addPoints(10);
    }
  };

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-green-400 via-emerald-500 to-teal-500'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center justify-between mb-6">
          <button
            onClick={() => onNavigate('lessons')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div className="text-center">
            <h1 className={`text-lg font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
              {lesson.title}
            </h1>
            {lesson.titleArabic && (
              <p className={`text-xl font-arabic ${isAdultMode ? 'text-emerald-200' : 'text-white/90'}`}>
                {lesson.titleArabic}
              </p>
            )}
          </div>
          <div className="w-10" />
        </header>

        <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-2 mb-6`}>
          <div className="flex items-center justify-between mb-2">
            <span className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
          <div className="flex gap-1">
            {steps.map((_, index) => (
              <div
                key={index}
                className={`flex-1 h-2 rounded-full transition-all ${
                  index < currentStep
                    ? (isAdultMode ? 'bg-emerald-400' : 'bg-green-400')
                    : index === currentStep
                      ? (isAdultMode ? 'bg-emerald-500' : 'bg-white')
                      : (isAdultMode ? 'bg-emerald-900' : 'bg-white/30')
                }`}
              />
            ))}
          </div>
        </div>

        <div className={`${isAdultMode ? 'bg-emerald-800/50' : 'bg-white/30'} backdrop-blur-sm rounded-3xl p-6 mb-6 min-h-[300px]`}>
          {step.type === "text" && (
            <div className="text-center">
              <p className={`text-xl ${isAdultMode ? 'text-white' : 'text-white'} leading-relaxed`}>
                {step.content}
              </p>
            </div>
          )}
          
          {step.type === "arabic" && (
            <div className="text-center">
              <p className={`text-lg mb-4 ${isAdultMode ? 'text-emerald-200' : 'text-white/90'}`}>
                {step.content}
              </p>
              <p className={`text-6xl font-arabic mb-4 ${isAdultMode ? 'text-white' : 'text-white'}`} dir="rtl">
                {step.arabic}
              </p>
              <p className={`text-2xl italic ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                {step.transliteration}
              </p>
              <button className={`mt-6 px-6 py-3 rounded-full ${isAdultMode ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-white/30 hover:bg-white/40'} flex items-center gap-2 mx-auto transition-colors`}>
                <Play className={`w-5 h-5 ${isAdultMode ? 'text-white' : 'text-white'}`} />
                <span className={`${isAdultMode ? 'text-white' : 'text-white'}`}>Listen</span>
              </button>
            </div>
          )}
          
          {step.type === "practice" && (
            <div className="text-center">
              <div className="text-5xl mb-4">🎤</div>
              <p className={`text-xl ${isAdultMode ? 'text-white' : 'text-white'} leading-relaxed`}>
                {step.content}
              </p>
              <p className={`mt-4 text-sm ${isAdultMode ? 'text-emerald-400' : 'text-white/70'}`}>
                Take your time to practice pronunciation
              </p>
            </div>
          )}
          
          {step.type === "quiz" && (
            <div className="text-center">
              <p className={`text-xl mb-6 ${isAdultMode ? 'text-white' : 'text-white'}`}>
                {step.content}
              </p>
              <div className="space-y-3">
                {step.options?.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswer(index)}
                    disabled={selectedAnswer !== null}
                    className={`w-full p-4 rounded-xl text-left transition-all ${
                      selectedAnswer === index
                        ? isCorrect
                          ? 'bg-green-500 text-white'
                          : 'bg-red-500 text-white'
                        : selectedAnswer !== null && index === step.correctAnswer
                          ? 'bg-green-500 text-white'
                          : (isAdultMode ? 'bg-emerald-700/50 hover:bg-emerald-700 text-white' : 'bg-white/20 hover:bg-white/30 text-white')
                    }`}
                  >
                    <span className="font-medium">{option}</span>
                  </button>
                ))}
              </div>
              {isCorrect !== null && (
                <p className={`mt-4 text-lg font-semibold ${isCorrect ? 'text-green-300' : 'text-red-300'}`}>
                  {isCorrect ? '🎉 Correct!' : '❌ Try again next time!'}
                </p>
              )}
            </div>
          )}
        </div>

        <button
          onClick={handleNext}
          disabled={step.type === "quiz" && selectedAnswer === null}
          className={`w-full py-4 rounded-2xl font-semibold text-lg flex items-center justify-center gap-2 transition-all ${
            step.type === "quiz" && selectedAnswer === null
              ? 'bg-gray-500/50 text-gray-300 cursor-not-allowed'
              : isLastStep
                ? (isAdultMode ? 'bg-gradient-to-r from-green-600 to-emerald-600' : 'bg-gradient-to-r from-yellow-400 to-orange-500')
                : (isAdultMode ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-white/30 hover:bg-white/40')
          } text-white`}
        >
          {isLastStep ? (
            <>
              <Check className="w-5 h-5" />
              Complete Lesson
            </>
          ) : (
            <>
              Continue
              <ChevronRight className="w-5 h-5" />
            </>
          )}
        </button>

        {!isAdultMode && (
          <div className="mt-4 flex justify-center gap-2">
            {Array.from({ length: 3 }).map((_, i) => (
              <Star
                key={i}
                className={`w-8 h-8 ${
                  i < Math.floor(((currentStep + 1) / steps.length) * 3)
                    ? 'text-yellow-300 fill-yellow-300'
                    : 'text-white/30'
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
