import { useLearning } from "@/lib/stores/useLearning";
import { ArrowLeft, Star, Trophy, Target, Book, Clock } from "lucide-react";

interface ProgressProps {
  onNavigate: (screen: string) => void;
}

export function Progress({ onNavigate }: ProgressProps) {
  const { isAdultMode, lessons, progress, totalPoints, streak, surahs } = useLearning();
  
  const completedLessons = Array.from(progress.values()).filter(p => p.completed).length;
  const totalLessons = lessons.length;
  const progressPercent = totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0;
  
  const totalPractice = Array.from(progress.values()).reduce((sum, p) => sum + p.practiceCount, 0);

  const achievements = [
    { id: 1, name: "First Steps", icon: "👣", description: "Complete your first lesson", unlocked: completedLessons >= 1 },
    { id: 2, name: "Dedicated Learner", icon: "📚", description: "Complete 5 lessons", unlocked: completedLessons >= 5 },
    { id: 3, name: "Practice Master", icon: "🎯", description: "Practice 10 times", unlocked: totalPractice >= 10 },
    { id: 4, name: "Star Collector", icon: "⭐", description: "Earn 100 points", unlocked: totalPoints >= 100 },
    { id: 5, name: "Week Warrior", icon: "🔥", description: "7-day streak", unlocked: streak >= 7 },
    { id: 6, name: "Hafiz in Training", icon: "📖", description: "Complete all Surahs", unlocked: false },
  ];

  return (
    <div className={`min-h-screen ${isAdultMode ? 'bg-gradient-to-b from-emerald-900 to-emerald-950' : 'bg-gradient-to-b from-orange-400 via-red-400 to-pink-500'}`}>
      <div className="container mx-auto px-4 py-6 max-w-lg">
        <header className="flex items-center gap-4 mb-6">
          <button
            onClick={() => onNavigate('home')}
            className={`p-2 rounded-full ${isAdultMode ? 'bg-emerald-800 text-emerald-100' : 'bg-white/20 text-white'}`}
          >
            <ArrowLeft size={24} />
          </button>
          <div>
            <h1 className={`text-2xl font-bold ${isAdultMode ? 'text-emerald-100' : 'text-white'} drop-shadow-lg`}>
              Your Progress
            </h1>
            <p className={`text-sm ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
              Track your learning journey
            </p>
          </div>
        </header>

        <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-3xl p-6 mb-6`}>
          <div className="text-center mb-4">
            <div className="relative inline-block">
              <svg className="w-32 h-32 transform -rotate-90">
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  className={`${isAdultMode ? 'text-emerald-900' : 'text-white/20'}`}
                />
                <circle
                  cx="64"
                  cy="64"
                  r="56"
                  stroke="currentColor"
                  strokeWidth="12"
                  fill="none"
                  strokeDasharray={`${progressPercent * 3.52} 352`}
                  className={`${isAdultMode ? 'text-emerald-400' : 'text-yellow-300'} transition-all duration-1000`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className={`text-3xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                  {progressPercent}%
                </span>
              </div>
            </div>
            <p className={`mt-2 ${isAdultMode ? 'text-emerald-200' : 'text-white'}`}>
              Overall Progress
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/20'} rounded-2xl p-4 text-center`}>
              <Book className={`w-6 h-6 mx-auto mb-2 ${isAdultMode ? 'text-blue-400' : 'text-blue-300'}`} />
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                {completedLessons}/{totalLessons}
              </p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                Lessons Done
              </p>
            </div>
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/20'} rounded-2xl p-4 text-center`}>
              <Target className={`w-6 h-6 mx-auto mb-2 ${isAdultMode ? 'text-green-400' : 'text-green-300'}`} />
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                {totalPractice}
              </p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                Practice Sessions
              </p>
            </div>
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/20'} rounded-2xl p-4 text-center`}>
              <Star className={`w-6 h-6 mx-auto mb-2 ${isAdultMode ? 'text-yellow-400' : 'text-yellow-300'}`} />
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                {totalPoints}
              </p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                Total Points
              </p>
            </div>
            <div className={`${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/20'} rounded-2xl p-4 text-center`}>
              <span className="text-2xl block mb-1">🔥</span>
              <p className={`text-xl font-bold ${isAdultMode ? 'text-white' : 'text-white'}`}>
                {streak}
              </p>
              <p className={`text-xs ${isAdultMode ? 'text-emerald-300' : 'text-white/80'}`}>
                Day Streak
              </p>
            </div>
          </div>
        </div>

        <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4 mb-6`}>
          <h2 className={`text-lg font-semibold mb-4 flex items-center gap-2 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
            <Trophy className={`w-5 h-5 ${isAdultMode ? 'text-yellow-400' : 'text-yellow-300'}`} />
            Achievements
          </h2>
          
          <div className="grid grid-cols-3 gap-3">
            {achievements.map((achievement) => (
              <div
                key={achievement.id}
                className={`p-3 rounded-xl text-center transition-all ${
                  achievement.unlocked
                    ? (isAdultMode ? 'bg-emerald-600' : 'bg-gradient-to-br from-yellow-400 to-orange-500')
                    : (isAdultMode ? 'bg-emerald-900/50 opacity-60' : 'bg-white/10 opacity-60')
                }`}
              >
                <span className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                  {achievement.icon}
                </span>
                <p className={`text-xs mt-1 font-medium ${achievement.unlocked ? 'text-white' : (isAdultMode ? 'text-emerald-400' : 'text-white/60')}`}>
                  {achievement.name}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className={`${isAdultMode ? 'bg-emerald-800/70' : 'bg-white/20'} backdrop-blur-sm rounded-2xl p-4`}>
          <h2 className={`text-lg font-semibold mb-4 ${isAdultMode ? 'text-emerald-100' : 'text-white'}`}>
            Lesson History
          </h2>
          
          {completedLessons > 0 ? (
            <div className="space-y-2">
              {lessons.filter(l => progress.get(l.id)?.completed).map((lesson) => (
                <div
                  key={lesson.id}
                  className={`flex items-center justify-between p-3 rounded-xl ${isAdultMode ? 'bg-emerald-700/50' : 'bg-white/10'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg ${isAdultMode ? 'bg-green-600' : 'bg-green-500'} flex items-center justify-center`}>
                      <span className="text-white text-sm">✓</span>
                    </div>
                    <div>
                      <p className={`font-medium ${isAdultMode ? 'text-white' : 'text-white'}`}>{lesson.title}</p>
                      <p className={`text-xs ${isAdultMode ? 'text-emerald-400' : 'text-white/60'}`}>
                        Practiced {progress.get(lesson.id)?.practiceCount || 0} times
                      </p>
                    </div>
                  </div>
                  <div className="flex">
                    {Array.from({ length: Math.min(progress.get(lesson.id)?.masteryLevel || 0, 3) }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className={`text-center py-6 ${isAdultMode ? 'text-emerald-400' : 'text-white/60'}`}>
              <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No lessons completed yet</p>
              <p className="text-sm">Start learning to track your progress!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
