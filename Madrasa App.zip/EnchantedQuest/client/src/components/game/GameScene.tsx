import { Suspense, useState, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { KeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { Player } from "./Player";
import { Environment } from "./Environment";
import { Secrets } from "./Secrets";
import { FollowCamera } from "./FollowCamera";
import { Lighting } from "./Lighting";
import { MagicalParticles, Fireflies } from "./Particles";
import { HUD } from "./HUD";
import { useExploration } from "@/lib/stores/useExploration";
import { useAudio } from "@/lib/stores/useAudio";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
}

const keyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
];

function LoadingScreen() {
  return (
    <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-indigo-900 to-black">
      <div className="text-center">
        <div className="text-4xl animate-spin mb-4">✨</div>
        <p className="text-purple-300 text-lg">Loading enchanted world...</p>
      </div>
    </div>
  );
}

function Scene() {
  const [playerPosition, setPlayerPosition] = useState(new THREE.Vector3(0, 0, 0));
  const { phase, discoveredCount, secrets } = useExploration();
  const { playSuccess, isMuted, backgroundMusic } = useAudio();
  const prevDiscoveredRef = useState(0);

  useEffect(() => {
    if (discoveredCount > prevDiscoveredRef[0]) {
      playSuccess();
      prevDiscoveredRef[0] = discoveredCount;
    }
  }, [discoveredCount, playSuccess]);

  useEffect(() => {
    if (backgroundMusic) {
      if (phase === "playing" && !isMuted) {
        backgroundMusic.play().catch(() => {});
      } else {
        backgroundMusic.pause();
      }
    }
  }, [phase, isMuted, backgroundMusic]);

  return (
    <>
      <color attach="background" args={["#0f0a1e"]} />
      <Lighting />
      
      <Suspense fallback={null}>
        <Environment />
        <Secrets />
        <Player onPositionChange={setPlayerPosition} />
        <MagicalParticles />
        <Fireflies />
      </Suspense>
      
      <FollowCamera targetPosition={playerPosition} />
    </>
  );
}

export function GameScene() {
  const { phase } = useExploration();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setIsLoading(false), 500);
    return () => clearTimeout(timer);
  }, []);

  if (phase !== "playing") return null;

  return (
    <div className="absolute inset-0">
      {isLoading && <LoadingScreen />}
      
      <KeyboardControls map={keyMap}>
        <Canvas
          shadows
          camera={{
            position: [0, 15, 20],
            fov: 50,
            near: 0.1,
            far: 100,
          }}
          gl={{
            antialias: true,
            toneMapping: THREE.ACESFilmicToneMapping,
            toneMappingExposure: 1.2,
          }}
        >
          <Scene />
        </Canvas>
        
        <HUD />
      </KeyboardControls>
    </div>
  );
}
