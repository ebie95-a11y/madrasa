import { useRef, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import * as THREE from "three";
import { useExploration } from "@/lib/stores/useExploration";

enum Controls {
  forward = "forward",
  backward = "backward",
  left = "left",
  right = "right",
}

interface PlayerProps {
  onPositionChange: (position: THREE.Vector3) => void;
}

export function Player({ onPositionChange }: PlayerProps) {
  const meshRef = useRef<THREE.Group>(null);
  const velocityRef = useRef(new THREE.Vector3());
  const [, getKeys] = useKeyboardControls<Controls>();
  const { phase, secrets, discoverSecret } = useExploration();
  
  const SPEED = 8;
  const FRICTION = 0.85;
  const BOUNDS = 35;
  const COLLECT_RADIUS = 2;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      console.log("Key pressed:", e.code);
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  useFrame((_, delta) => {
    if (!meshRef.current || phase !== "playing") return;
    
    const keys = getKeys();
    const direction = new THREE.Vector3();
    
    if (keys.forward) direction.z -= 1;
    if (keys.backward) direction.z += 1;
    if (keys.left) direction.x -= 1;
    if (keys.right) direction.x += 1;
    
    if (direction.length() > 0) {
      direction.normalize();
      velocityRef.current.add(direction.multiplyScalar(SPEED * delta));
    }
    
    velocityRef.current.multiplyScalar(FRICTION);
    
    meshRef.current.position.add(velocityRef.current);
    
    meshRef.current.position.x = Math.max(-BOUNDS, Math.min(BOUNDS, meshRef.current.position.x));
    meshRef.current.position.z = Math.max(-BOUNDS, Math.min(BOUNDS, meshRef.current.position.z));
    meshRef.current.position.y = 0.5;
    
    if (velocityRef.current.length() > 0.01) {
      const targetRotation = Math.atan2(velocityRef.current.x, velocityRef.current.z);
      meshRef.current.rotation.y = THREE.MathUtils.lerp(
        meshRef.current.rotation.y,
        targetRotation,
        0.1
      );
    }
    
    onPositionChange(meshRef.current.position.clone());
    
    secrets.forEach((secret) => {
      if (!secret.discovered) {
        const secretPos = new THREE.Vector3(...secret.position);
        const distance = meshRef.current!.position.distanceTo(secretPos);
        if (distance < COLLECT_RADIUS) {
          discoverSecret(secret.id);
        }
      }
    });
  });

  return (
    <group ref={meshRef} position={[0, 0.5, 0]}>
      <mesh castShadow>
        <capsuleGeometry args={[0.3, 0.6, 8, 16]} />
        <meshStandardMaterial 
          color="#8b5cf6" 
          emissive="#4c1d95"
          emissiveIntensity={0.3}
        />
      </mesh>
      
      <mesh position={[0, 0.5, 0]} castShadow>
        <sphereGeometry args={[0.25, 16, 16]} />
        <meshStandardMaterial 
          color="#c4b5fd" 
          emissive="#7c3aed"
          emissiveIntensity={0.2}
        />
      </mesh>
      
      <pointLight 
        position={[0, 1, 0]} 
        color="#a78bfa" 
        intensity={2} 
        distance={4} 
      />
    </group>
  );
}
