import { useExploration } from "@/lib/stores/useExploration";
import { useAudio } from "@/lib/stores/useAudio";

export function HUD() {
  const { discoveredCount, totalSecrets, score, showTutorial, dismissTutorial, phase } = useExploration();
  const { isMuted, toggleMute } = useAudio();

  if (phase !== "playing") return null;

  return (
    <div className="absolute inset-0 pointer-events-none">
      <div className="absolute top-4 left-4 pointer-events-auto">
        <div className="bg-black/70 backdrop-blur-sm rounded-xl p-4 border border-purple-500/30 shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <span className="text-white text-sm">✨</span>
            </div>
            <div>
              <p className="text-purple-300 text-xs uppercase tracking-wider">Secrets Found</p>
              <p className="text-white text-xl font-bold">
                {discoveredCount} <span className="text-purple-400 text-sm">/ {totalSecrets}</span>
              </p>
            </div>
          </div>
          
          <div className="w-full bg-gray-700 rounded-full h-2 mb-3">
            <div
              className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-500"
              style={{ width: `${(discoveredCount / totalSecrets) * 100}%` }}
            />
          </div>
          
          <div className="flex items-center gap-2">
            <span className="text-yellow-400">⭐</span>
            <span className="text-white font-semibold">{score}</span>
            <span className="text-gray-400 text-sm">points</span>
          </div>
        </div>
      </div>
      
      <div className="absolute top-4 right-4 pointer-events-auto">
        <button
          onClick={toggleMute}
          className="bg-black/70 backdrop-blur-sm rounded-lg p-3 border border-purple-500/30 hover:bg-purple-900/50 transition-colors"
        >
          <span className="text-white text-lg">{isMuted ? "🔇" : "🔊"}</span>
        </button>
      </div>
      
      {showTutorial && (
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 pointer-events-auto">
          <div className="bg-black/80 backdrop-blur-sm rounded-xl p-6 border border-purple-500/30 shadow-xl max-w-md">
            <h3 className="text-purple-300 text-lg font-bold mb-4 text-center">Welcome to the Enchanted Forest!</h3>
            
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="flex items-center gap-2">
                <div className="bg-purple-700 rounded-lg px-3 py-1">
                  <span className="text-white font-mono text-sm">W</span>
                </div>
                <span className="text-gray-300 text-sm">Move forward</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-purple-700 rounded-lg px-3 py-1">
                  <span className="text-white font-mono text-sm">S</span>
                </div>
                <span className="text-gray-300 text-sm">Move back</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-purple-700 rounded-lg px-3 py-1">
                  <span className="text-white font-mono text-sm">A</span>
                </div>
                <span className="text-gray-300 text-sm">Move left</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="bg-purple-700 rounded-lg px-3 py-1">
                  <span className="text-white font-mono text-sm">D</span>
                </div>
                <span className="text-gray-300 text-sm">Move right</span>
              </div>
            </div>
            
            <p className="text-gray-400 text-sm text-center mb-4">
              Explore the forest and collect glowing secrets!
            </p>
            
            <button
              onClick={dismissTutorial}
              className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-2 px-4 rounded-lg hover:from-purple-500 hover:to-pink-500 transition-all font-semibold"
            >
              Got it!
            </button>
          </div>
        </div>
      )}
      
      {discoveredCount === totalSecrets && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 pointer-events-auto">
          <div className="bg-black/90 backdrop-blur-sm rounded-2xl p-8 border border-yellow-500/50 shadow-2xl text-center">
            <div className="text-6xl mb-4">🏆</div>
            <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 mb-2">
              Congratulations!
            </h2>
            <p className="text-purple-300 text-lg mb-4">You found all the secrets!</p>
            <p className="text-2xl text-white font-bold mb-6">
              Final Score: <span className="text-yellow-400">{score}</span>
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
