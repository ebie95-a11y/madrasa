import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

interface FollowCameraProps {
  targetPosition: THREE.Vector3;
}

export function FollowCamera({ targetPosition }: FollowCameraProps) {
  const { camera } = useThree();
  const smoothedPosition = useRef(new THREE.Vector3(0, 15, 20));
  const smoothedLookAt = useRef(new THREE.Vector3(0, 0, 0));
  
  const CAMERA_HEIGHT = 12;
  const CAMERA_DISTANCE = 15;
  const SMOOTH_FACTOR = 0.05;

  useFrame(() => {
    const idealPosition = new THREE.Vector3(
      targetPosition.x,
      targetPosition.y + CAMERA_HEIGHT,
      targetPosition.z + CAMERA_DISTANCE
    );
    
    smoothedPosition.current.lerp(idealPosition, SMOOTH_FACTOR);
    
    smoothedLookAt.current.lerp(targetPosition, SMOOTH_FACTOR);
    
    camera.position.copy(smoothedPosition.current);
    camera.lookAt(smoothedLookAt.current);
  });

  return null;
}
