import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useExploration, Secret } from "@/lib/stores/useExploration";

interface SecretItemProps {
  secret: Secret;
}

function SecretOrb({ secret }: SecretItemProps) {
  const groupRef = useRef<THREE.Group>(null);
  const innerRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (!groupRef.current || secret.discovered) return;
    
    groupRef.current.position.y = secret.position[1] + Math.sin(state.clock.elapsedTime * 2 + secret.position[0]) * 0.2;
    groupRef.current.rotation.y = state.clock.elapsedTime;
    
    if (innerRef.current) {
      const material = innerRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.5 + Math.sin(state.clock.elapsedTime * 3) * 0.3;
    }
  });

  if (secret.discovered) return null;

  return (
    <group ref={groupRef} position={secret.position}>
      <mesh ref={innerRef}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial
          color={secret.color}
          emissive={secret.color}
          emissiveIntensity={0.5}
          transparent
          opacity={0.8}
        />
      </mesh>
      
      <mesh scale={1.2}>
        <sphereGeometry args={[0.3, 16, 16]} />
        <meshStandardMaterial
          color={secret.color}
          transparent
          opacity={0.2}
          side={THREE.BackSide}
        />
      </mesh>
      
      <pointLight color={secret.color} intensity={2} distance={5} />
    </group>
  );
}

function SecretCrystal({ secret }: SecretItemProps) {
  const groupRef = useRef<THREE.Group>(null);
  const crystalRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (!groupRef.current || secret.discovered) return;
    
    groupRef.current.position.y = secret.position[1] + Math.sin(state.clock.elapsedTime * 1.5 + secret.position[2]) * 0.15;
    groupRef.current.rotation.y = state.clock.elapsedTime * 0.5;
    
    if (crystalRef.current) {
      const material = crystalRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.4 + Math.sin(state.clock.elapsedTime * 4) * 0.2;
    }
  });

  if (secret.discovered) return null;

  return (
    <group ref={groupRef} position={secret.position}>
      <mesh ref={crystalRef} rotation={[0, 0, Math.PI]}>
        <octahedronGeometry args={[0.4, 0]} />
        <meshStandardMaterial
          color={secret.color}
          emissive={secret.color}
          emissiveIntensity={0.4}
          transparent
          opacity={0.85}
          roughness={0.1}
          metalness={0.8}
        />
      </mesh>
      
      <pointLight color={secret.color} intensity={3} distance={6} />
    </group>
  );
}

function SecretMushroom({ secret }: SecretItemProps) {
  const groupRef = useRef<THREE.Group>(null);
  const capRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (!groupRef.current || secret.discovered) return;
    
    const scale = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.1;
    groupRef.current.scale.set(scale, scale, scale);
    
    if (capRef.current) {
      const material = capRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.5 + Math.sin(state.clock.elapsedTime * 3) * 0.3;
    }
  });

  if (secret.discovered) return null;

  return (
    <group ref={groupRef} position={secret.position}>
      <mesh position={[0, 0.15, 0]}>
        <cylinderGeometry args={[0.08, 0.12, 0.3, 8]} />
        <meshStandardMaterial color="#f5f5dc" />
      </mesh>
      
      <mesh ref={capRef} position={[0, 0.35, 0]}>
        <sphereGeometry args={[0.25, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial
          color={secret.color}
          emissive={secret.color}
          emissiveIntensity={0.5}
        />
      </mesh>
      
      <pointLight color={secret.color} intensity={2} distance={4} />
    </group>
  );
}

function SecretFlower({ secret }: SecretItemProps) {
  const groupRef = useRef<THREE.Group>(null);
  const petalRef = useRef<THREE.Group>(null);
  
  useFrame((state) => {
    if (!groupRef.current || secret.discovered) return;
    
    groupRef.current.position.y = secret.position[1] + Math.sin(state.clock.elapsedTime * 2.5) * 0.1;
    
    if (petalRef.current) {
      petalRef.current.rotation.y = state.clock.elapsedTime * 0.3;
    }
  });

  if (secret.discovered) return null;

  return (
    <group ref={groupRef} position={secret.position}>
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.03, 0.03, 0.4, 8]} />
        <meshStandardMaterial color="#22c55e" />
      </mesh>
      
      <group ref={petalRef} position={[0, 0.45, 0]}>
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <mesh key={i} rotation={[0.3, (i / 6) * Math.PI * 2, 0]} position={[0, 0, 0]}>
            <sphereGeometry args={[0.12, 8, 8]} />
            <meshStandardMaterial
              color={secret.color}
              emissive={secret.color}
              emissiveIntensity={0.4}
            />
          </mesh>
        ))}
        
        <mesh>
          <sphereGeometry args={[0.08, 8, 8]} />
          <meshStandardMaterial color="#fbbf24" emissive="#fbbf24" emissiveIntensity={0.5} />
        </mesh>
      </group>
      
      <pointLight color={secret.color} intensity={1.5} distance={4} />
    </group>
  );
}

export function Secrets() {
  const { secrets } = useExploration();

  return (
    <group>
      {secrets.map((secret) => {
        switch (secret.type) {
          case "orb":
            return <SecretOrb key={secret.id} secret={secret} />;
          case "crystal":
            return <SecretCrystal key={secret.id} secret={secret} />;
          case "mushroom":
            return <SecretMushroom key={secret.id} secret={secret} />;
          case "flower":
            return <SecretFlower key={secret.id} secret={secret} />;
          default:
            return null;
        }
      })}
    </group>
  );
}
