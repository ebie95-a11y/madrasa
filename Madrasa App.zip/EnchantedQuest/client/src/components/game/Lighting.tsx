import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

export function Lighting() {
  const spotLightRef = useRef<THREE.SpotLight>(null);
  
  useFrame((state) => {
    if (spotLightRef.current) {
      spotLightRef.current.intensity = 0.8 + Math.sin(state.clock.elapsedTime * 0.5) * 0.1;
    }
  });

  return (
    <>
      <ambientLight intensity={0.3} color="#9ca3af" />
      
      <directionalLight
        position={[10, 20, 10]}
        intensity={0.8}
        color="#fef3c7"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-far={100}
        shadow-camera-left={-50}
        shadow-camera-right={50}
        shadow-camera-top={50}
        shadow-camera-bottom={-50}
      />
      
      <spotLight
        ref={spotLightRef}
        position={[-15, 25, -15]}
        angle={0.5}
        penumbra={1}
        intensity={0.8}
        color="#c4b5fd"
        castShadow
      />
      
      <pointLight position={[0, 10, 0]} intensity={0.5} color="#a78bfa" distance={30} />
      
      <hemisphereLight
        color="#87ceeb"
        groundColor="#2d5a3d"
        intensity={0.4}
      />
      
      <fog attach="fog" args={["#1a1a2e", 20, 60]} />
    </>
  );
}
