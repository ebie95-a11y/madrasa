import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useTexture } from "@react-three/drei";
import * as THREE from "three";

interface TreeProps {
  position: [number, number, number];
  scale?: number;
}

function MagicalTree({ position, scale = 1 }: TreeProps) {
  const trunkRef = useRef<THREE.Mesh>(null);
  const leavesRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (leavesRef.current) {
      leavesRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.5 + position[0]) * 0.05;
    }
  });

  return (
    <group position={position} scale={scale}>
      <mesh ref={trunkRef} position={[0, 1.5, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[0.2, 0.4, 3, 8]} />
        <meshStandardMaterial color="#4a3728" roughness={0.9} />
      </mesh>
      
      <mesh ref={leavesRef} position={[0, 3.5, 0]} castShadow>
        <coneGeometry args={[1.5, 3, 8]} />
        <meshStandardMaterial 
          color="#1a472a" 
          emissive="#0a2a1a"
          emissiveIntensity={0.1}
        />
      </mesh>
      
      <mesh position={[0, 5, 0]} castShadow>
        <coneGeometry args={[1, 2, 8]} />
        <meshStandardMaterial 
          color="#2d5a3d" 
          emissive="#1a3a2a"
          emissiveIntensity={0.15}
        />
      </mesh>
      
      <pointLight 
        position={[0, 4, 0]} 
        color="#4ade80" 
        intensity={0.3} 
        distance={3} 
      />
    </group>
  );
}

interface RockProps {
  position: [number, number, number];
  scale?: number;
  rotation?: number;
}

function MagicalRock({ position, scale = 1, rotation = 0 }: RockProps) {
  return (
    <group position={position} rotation={[0, rotation, 0]} scale={scale}>
      <mesh castShadow receiveShadow>
        <dodecahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial 
          color="#64748b" 
          roughness={0.8}
          metalness={0.1}
        />
      </mesh>
      <pointLight 
        position={[0, 0.5, 0]} 
        color="#93c5fd" 
        intensity={0.2} 
        distance={2} 
      />
    </group>
  );
}

function GlowingMushroom({ position, color }: { position: [number, number, number]; color: string }) {
  const mushroomRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (mushroomRef.current) {
      const material = mushroomRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.3 + Math.sin(state.clock.elapsedTime * 2 + position[0]) * 0.2;
    }
  });

  return (
    <group position={position}>
      <mesh position={[0, 0.1, 0]}>
        <cylinderGeometry args={[0.05, 0.08, 0.2, 8]} />
        <meshStandardMaterial color="#f5f5dc" />
      </mesh>
      
      <mesh ref={mushroomRef} position={[0, 0.25, 0]}>
        <sphereGeometry args={[0.15, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2]} />
        <meshStandardMaterial 
          color={color} 
          emissive={color}
          emissiveIntensity={0.3}
        />
      </mesh>
      
      <pointLight 
        position={[0, 0.3, 0]} 
        color={color} 
        intensity={0.5} 
        distance={2} 
      />
    </group>
  );
}

export function Environment() {
  const grassTexture = useTexture("/textures/grass.png");
  
  grassTexture.wrapS = grassTexture.wrapT = THREE.RepeatWrapping;
  grassTexture.repeat.set(20, 20);

  const trees = useMemo(() => {
    const items: Array<{ position: [number, number, number]; scale: number }> = [];
    for (let i = 0; i < 40; i++) {
      const angle = (i / 40) * Math.PI * 2;
      const radius = 15 + (i % 5) * 5;
      const x = Math.cos(angle) * radius + (Math.sin(i * 137.5) * 5);
      const z = Math.sin(angle) * radius + (Math.cos(i * 137.5) * 5);
      items.push({
        position: [x, 0, z] as [number, number, number],
        scale: 0.7 + Math.abs(Math.sin(i * 2.3)) * 0.6,
      });
    }
    return items;
  }, []);

  const rocks = useMemo(() => {
    const items: Array<{ position: [number, number, number]; scale: number; rotation: number }> = [];
    for (let i = 0; i < 20; i++) {
      const angle = (i / 20) * Math.PI * 2 + Math.PI / 4;
      const radius = 10 + (i % 3) * 8;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      items.push({
        position: [x, 0.4, z] as [number, number, number],
        scale: 0.5 + Math.abs(Math.sin(i * 1.7)) * 0.8,
        rotation: i * 0.7,
      });
    }
    return items;
  }, []);

  const mushrooms = useMemo(() => {
    const colors = ["#ff6b9d", "#4ade80", "#60a5fa", "#f472b6", "#a78bfa"];
    const items: Array<{ position: [number, number, number]; color: string }> = [];
    for (let i = 0; i < 30; i++) {
      const angle = (i / 30) * Math.PI * 2;
      const radius = 5 + (i % 6) * 4;
      const x = Math.cos(angle) * radius + Math.sin(i * 53.7) * 2;
      const z = Math.sin(angle) * radius + Math.cos(i * 53.7) * 2;
      items.push({
        position: [x, 0, z] as [number, number, number],
        color: colors[i % colors.length],
      });
    }
    return items;
  }, []);

  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
        <planeGeometry args={[80, 80]} />
        <meshStandardMaterial 
          map={grassTexture} 
          color="#2d5a3d"
        />
      </mesh>
      
      {trees.map((tree, i) => (
        <MagicalTree key={`tree-${i}`} position={tree.position} scale={tree.scale} />
      ))}
      
      {rocks.map((rock, i) => (
        <MagicalRock 
          key={`rock-${i}`} 
          position={rock.position} 
          scale={rock.scale}
          rotation={rock.rotation}
        />
      ))}
      
      {mushrooms.map((mushroom, i) => (
        <GlowingMushroom 
          key={`mushroom-${i}`} 
          position={mushroom.position} 
          color={mushroom.color}
        />
      ))}
    </group>
  );
}
