import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export interface Surah {
  id: number;
  number: number;
  nameArabic: string;
  nameEnglish: string;
  nameTransliteration: string;
  versesCount: number;
  difficulty: number;
}

export interface Verse {
  id: number;
  surahId: number;
  verseNumber: number;
  textArabic: string;
  textTransliteration: string;
  translation: string;
  tajweedRules?: TajweedRule[];
}

export interface TajweedRule {
  type: string;
  name: string;
  color: string;
  startIndex: number;
  endIndex: number;
}

export interface Lesson {
  id: number;
  title: string;
  titleArabic?: string;
  description: string;
  category: string;
  orderIndex: number;
  surahId?: number;
  difficulty: number;
  completed?: boolean;
}

export interface UserProgress {
  lessonId: number;
  completed: boolean;
  masteryLevel: number;
  practiceCount: number;
}

interface LearningState {
  isAdultMode: boolean;
  currentSurah: Surah | null;
  currentVerse: number;
  currentLesson: Lesson | null;
  surahs: Surah[];
  lessons: Lesson[];
  progress: Map<number, UserProgress>;
  totalPoints: number;
  streak: number;
  isPlaying: boolean;
  showTajweed: boolean;
  
  setAdultMode: (isAdult: boolean) => void;
  setCurrentSurah: (surah: Surah | null) => void;
  setCurrentVerse: (verse: number) => void;
  setCurrentLesson: (lesson: Lesson | null) => void;
  setSurahs: (surahs: Surah[]) => void;
  setLessons: (lessons: Lesson[]) => void;
  completeLesson: (lessonId: number) => void;
  addPoints: (points: number) => void;
  togglePlaying: () => void;
  toggleTajweed: () => void;
  incrementStreak: () => void;
}

const shortSurahs: Surah[] = [
  { id: 1, number: 1, nameArabic: "الفاتحة", nameEnglish: "The Opening", nameTransliteration: "Al-Fatiha", versesCount: 7, difficulty: 1 },
  { id: 2, number: 78, nameArabic: "النبأ", nameEnglish: "The Tidings / The News", nameTransliteration: "An-Naba", versesCount: 40, difficulty: 2 },
  { id: 3, number: 79, nameArabic: "الناشعات", nameEnglish: "Those Who Drag Forth", nameTransliteration: "An-Nazi'at", versesCount: 46, difficulty: 2 },
  { id: 4, number: 80, nameArabic: "عبس", nameEnglish: "He Frowned", nameTransliteration: "Abasa", versesCount: 42, difficulty: 2 },
  { id: 5, number: 81, nameArabic: "التكوير", nameEnglish: "The Overthrowing", nameTransliteration: "At-Takwir", versesCount: 29, difficulty: 2 },
  { id: 6, number: 82, nameArabic: "الانفطار", nameEnglish: "The Cleaving / The Splitting", nameTransliteration: "Al-Infitar", versesCount: 19, difficulty: 2 },
  { id: 7, number: 83, nameArabic: "المطففين", nameEnglish: "The Defrauding / Those Who Give Less", nameTransliteration: "Al-Mutaffifin", versesCount: 36, difficulty: 2 },
  { id: 8, number: 84, nameArabic: "الانشقاق", nameEnglish: "The Splitting Open", nameTransliteration: "Al-Inshiqaq", versesCount: 25, difficulty: 2 },
  { id: 9, number: 85, nameArabic: "البروج", nameEnglish: "The Mansions of the Stars", nameTransliteration: "Al-Buruj", versesCount: 22, difficulty: 2 },
  { id: 10, number: 86, nameArabic: "الطارق", nameEnglish: "The Morning Star / The Nightcomer", nameTransliteration: "At-Tariq", versesCount: 17, difficulty: 2 },
  { id: 11, number: 87, nameArabic: "الأعلى", nameEnglish: "The Most High", nameTransliteration: "Al-A'la", versesCount: 19, difficulty: 2 },
  { id: 12, number: 88, nameArabic: "الغاشية", nameEnglish: "The Overwhelming", nameTransliteration: "Al-Ghashiyah", versesCount: 26, difficulty: 2 },
  { id: 13, number: 89, nameArabic: "الفجر", nameEnglish: "The Dawn", nameTransliteration: "Al-Fajr", versesCount: 30, difficulty: 2 },
  { id: 14, number: 90, nameArabic: "البلد", nameEnglish: "The City", nameTransliteration: "Al-Balad", versesCount: 20, difficulty: 2 },
  { id: 15, number: 91, nameArabic: "الشمس", nameEnglish: "The Sun", nameTransliteration: "Ash-Shams", versesCount: 15, difficulty: 2 },
  { id: 16, number: 92, nameArabic: "الليل", nameEnglish: "The Night", nameTransliteration: "Al-Layl", versesCount: 21, difficulty: 2 },
  { id: 17, number: 93, nameArabic: "الضحى", nameEnglish: "The Morning Hours", nameTransliteration: "Ad-Duha", versesCount: 11, difficulty: 2 },
  { id: 18, number: 94, nameArabic: "الشرح", nameEnglish: "The Relief / The Opening-Up", nameTransliteration: "Ash-Sharh", versesCount: 8, difficulty: 2 },
  { id: 19, number: 95, nameArabic: "التين", nameEnglish: "The Fig", nameTransliteration: "At-Tin", versesCount: 8, difficulty: 2 },
  { id: 20, number: 96, nameArabic: "العلق", nameEnglish: "The Clot / The Embryo", nameTransliteration: "Al-Alaq", versesCount: 19, difficulty: 2 },
  { id: 21, number: 97, nameArabic: "القدر", nameEnglish: "The Power / The Night of Decree", nameTransliteration: "Al-Qadr", versesCount: 5, difficulty: 2 },
  { id: 22, number: 98, nameArabic: "البينة", nameEnglish: "The Clear Proof", nameTransliteration: "Al-Bayyinah", versesCount: 8, difficulty: 2 },
  { id: 23, number: 99, nameArabic: "الزلزلة", nameEnglish: "The Earthquake", nameTransliteration: "Az-Zalzalah", versesCount: 8, difficulty: 2 },
  { id: 24, number: 100, nameArabic: "العاديات", nameEnglish: "The Courser / Those That Run", nameTransliteration: "Al-Adiyat", versesCount: 11, difficulty: 2 },
  { id: 25, number: 101, nameArabic: "القارعة", nameEnglish: "The Striking Hour", nameTransliteration: "Al-Qari'ah", versesCount: 11, difficulty: 2 },
  { id: 26, number: 102, nameArabic: "التكاثر", nameEnglish: "Rivalry in Worldly Increase", nameTransliteration: "At-Takathur", versesCount: 8, difficulty: 2 },
  { id: 27, number: 103, nameArabic: "العصر", nameEnglish: "Time / The Declining Day", nameTransliteration: "Al-Asr", versesCount: 3, difficulty: 2 },
  { id: 28, number: 104, nameArabic: "الهمزة", nameEnglish: "The Slanderer", nameTransliteration: "Al-Humazah", versesCount: 9, difficulty: 2 },
  { id: 29, number: 105, nameArabic: "الفيل", nameEnglish: "The Elephant", nameTransliteration: "Al-Fil", versesCount: 5, difficulty: 2 },
  { id: 30, number: 106, nameArabic: "قريش", nameEnglish: "Quraysh", nameTransliteration: "Quraysh", versesCount: 4, difficulty: 2 },
  { id: 31, number: 107, nameArabic: "الماعون", nameEnglish: "Small Kindnesses", nameTransliteration: "Al-Ma'un", versesCount: 7, difficulty: 2 },
  { id: 32, number: 108, nameArabic: "الكوثر", nameEnglish: "The Abundance", nameTransliteration: "Al-Kawthar", versesCount: 3, difficulty: 2 },
  { id: 33, number: 109, nameArabic: "الكافرون", nameEnglish: "The Disbelievers", nameTransliteration: "Al-Kafirun", versesCount: 6, difficulty: 2 },
  { id: 34, number: 110, nameArabic: "النصر", nameEnglish: "The Help", nameTransliteration: "An-Nasr", versesCount: 3, difficulty: 2 },
  { id: 35, number: 111, nameArabic: "المسد", nameEnglish: "The Palm Fiber", nameTransliteration: "Al-Masad", versesCount: 5, difficulty: 2 },
  { id: 36, number: 112, nameArabic: "الإخلاص", nameEnglish: "The Sincerity", nameTransliteration: "Al-Ikhlas", versesCount: 4, difficulty: 2 },
  { id: 37, number: 113, nameArabic: "الفلق", nameEnglish: "The Daybreak", nameTransliteration: "Al-Falaq", versesCount: 5, difficulty: 2 },
  { id: 38, number: 114, nameArabic: "الناس", nameEnglish: "Mankind", nameTransliteration: "An-Nas", versesCount: 6, difficulty: 2 },
];

const defaultLessons: Lesson[] = [
  { id: 1, title: "Arabic Alphabet", titleArabic: "الحروف العربية", description: "Learn the Arabic letters", category: "basics", orderIndex: 1, difficulty: 1 },
  { id: 2, title: "Short Vowels", titleArabic: "الحركات", description: "Learn Fatha, Kasra, and Damma", category: "basics", orderIndex: 2, difficulty: 1 },
  { id: 3, title: "Long Vowels", titleArabic: "المد", description: "Learn Alif, Waw, and Ya", category: "basics", orderIndex: 3, difficulty: 1 },
  { id: 4, title: "Letter Sounds A-H", titleArabic: "أصوات الحروف أ-ح", description: "Practice identifying sounds of letters Alif through Ha", category: "practice", orderIndex: 4, difficulty: 1 },
  { id: 5, title: "Letter Sounds I-Q", titleArabic: "أصوات الحروف ي-ق", description: "Practice identifying sounds of letters Ya through Qaf", category: "practice", orderIndex: 5, difficulty: 1 },
  { id: 6, title: "Letter Sounds R-Z", titleArabic: "أصوات الحروف ر-ز", description: "Practice identifying sounds of letters Ra through Za", category: "practice", orderIndex: 6, difficulty: 2 },
  { id: 7, title: "Surah Al-Fatiha", titleArabic: "سورة الفاتحة", description: "Learn to recite the Opening", category: "surah", orderIndex: 7, surahId: 1, difficulty: 1 },
  { id: 8, title: "Surah Al-Ikhlas", titleArabic: "سورة الإخلاص", description: "Learn to recite Al-Ikhlas", category: "surah", orderIndex: 8, surahId: 112, difficulty: 1 },
  { id: 9, title: "Surah Al-Falaq", titleArabic: "سورة الفلق", description: "Learn to recite Al-Falaq", category: "surah", orderIndex: 9, surahId: 113, difficulty: 1 },
  { id: 10, title: "Surah An-Nas", titleArabic: "سورة الناس", description: "Learn to recite An-Nas", category: "surah", orderIndex: 10, surahId: 114, difficulty: 1 },
];

export const useLearning = create<LearningState>()(
  subscribeWithSelector((set, get) => ({
    isAdultMode: false,
    currentSurah: null,
    currentVerse: 1,
    currentLesson: null,
    surahs: shortSurahs,
    lessons: defaultLessons,
    progress: new Map(),
    totalPoints: 0,
    streak: 0,
    isPlaying: false,
    showTajweed: true,
    
    setAdultMode: (isAdult) => set({ isAdultMode: isAdult }),
    
    setCurrentSurah: (surah) => set({ currentSurah: surah, currentVerse: 1 }),
    
    setCurrentVerse: (verse) => set({ currentVerse: verse }),
    
    setCurrentLesson: (lesson) => set({ currentLesson: lesson }),
    
    setSurahs: (surahs) => set({ surahs }),
    
    setLessons: (lessons) => set({ lessons }),
    
    completeLesson: (lessonId) => {
      const progress = new Map(get().progress);
      const existing = progress.get(lessonId);
      progress.set(lessonId, {
        lessonId,
        completed: true,
        masteryLevel: (existing?.masteryLevel || 0) + 1,
        practiceCount: (existing?.practiceCount || 0) + 1,
      });
      set({ progress, totalPoints: get().totalPoints + 10 });
    },
    
    addPoints: (points) => set({ totalPoints: get().totalPoints + points }),
    
    togglePlaying: () => set({ isPlaying: !get().isPlaying }),
    
    toggleTajweed: () => set({ showTajweed: !get().showTajweed }),
    
    incrementStreak: () => set({ streak: get().streak + 1 }),
  }))
);
