import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

export type GamePhase = "menu" | "tutorial" | "playing" | "paused";

export interface Secret {
  id: string;
  position: [number, number, number];
  type: "orb" | "crystal" | "mushroom" | "flower";
  color: string;
  discovered: boolean;
  points: number;
}

interface ExplorationState {
  phase: GamePhase;
  secrets: Secret[];
  discoveredCount: number;
  totalSecrets: number;
  score: number;
  showTutorial: boolean;
  
  startGame: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
  restartGame: () => void;
  discoverSecret: (id: string) => void;
  dismissTutorial: () => void;
  initializeSecrets: (secrets: Secret[]) => void;
}

const generateSecrets = (): Secret[] => {
  const secrets: Secret[] = [];
  const types: Array<"orb" | "crystal" | "mushroom" | "flower"> = ["orb", "crystal", "mushroom", "flower"];
  const colors = ["#00ffff", "#ff00ff", "#ffff00", "#00ff00", "#ff6600", "#6600ff"];
  
  for (let i = 0; i < 15; i++) {
    const angle = (i / 15) * Math.PI * 2 + Math.random() * 0.5;
    const radius = 8 + Math.random() * 20;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    
    secrets.push({
      id: `secret-${i}`,
      position: [x, 0.5, z],
      type: types[Math.floor(Math.random() * types.length)],
      color: colors[Math.floor(Math.random() * colors.length)],
      discovered: false,
      points: types[Math.floor(Math.random() * types.length)] === "crystal" ? 50 : 25,
    });
  }
  
  return secrets;
};

export const useExploration = create<ExplorationState>()(
  subscribeWithSelector((set, get) => ({
    phase: "menu",
    secrets: generateSecrets(),
    discoveredCount: 0,
    totalSecrets: 15,
    score: 0,
    showTutorial: true,
    
    startGame: () => {
      const currentState = get();
      if (currentState.discoveredCount > 0) {
        set({
          phase: "playing",
          secrets: generateSecrets(),
          discoveredCount: 0,
          score: 0,
          showTutorial: true,
        });
      } else {
        set({ phase: "playing", showTutorial: true });
      }
      console.log("Game started, phase is now: playing");
    },
    
    pauseGame: () => {
      set((state) => {
        if (state.phase === "playing") {
          return { phase: "paused" };
        }
        return {};
      });
    },
    
    resumeGame: () => {
      set((state) => {
        if (state.phase === "paused") {
          return { phase: "playing" };
        }
        return {};
      });
    },
    
    restartGame: () => {
      set({
        phase: "menu",
        secrets: generateSecrets(),
        discoveredCount: 0,
        score: 0,
        showTutorial: true,
      });
    },
    
    discoverSecret: (id: string) => {
      set((state) => {
        const secrets = state.secrets.map((secret) => {
          if (secret.id === id && !secret.discovered) {
            return { ...secret, discovered: true };
          }
          return secret;
        });
        
        const discoveredSecret = state.secrets.find((s) => s.id === id);
        const newScore = discoveredSecret && !discoveredSecret.discovered 
          ? state.score + discoveredSecret.points 
          : state.score;
        const newCount = secrets.filter((s) => s.discovered).length;
        
        return {
          secrets,
          discoveredCount: newCount,
          score: newScore,
        };
      });
    },
    
    dismissTutorial: () => {
      set({ showTutorial: false });
    },
    
    initializeSecrets: (secrets: Secret[]) => {
      set({ secrets, totalSecrets: secrets.length });
    },
  }))
);
