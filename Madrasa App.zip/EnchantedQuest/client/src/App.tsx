import { useState, useEffect } from "react";
import "@fontsource/inter";
import {
  Home,
  LessonList,
  LessonView,
  SurahList,
  SurahReader,
  DuasList,
  Progress,
  Settings,
} from "./components/learning";
import { useLearning, Lesson, Surah } from "./lib/stores/useLearning";
import { useAudio } from "./lib/stores/useAudio";

type Screen = "home" | "lessons" | "lesson" | "surahs" | "surah" | "duas" | "progress" | "settings";

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>("home");
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [selectedSurah, setSelectedSurah] = useState<Surah | null>(null);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  useEffect(() => {
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.2;
    setBackgroundMusic(bgMusic);

    const hitSfx = new Audio("/sounds/hit.mp3");
    hitSfx.volume = 0.3;
    setHitSound(hitSfx);

    const successSfx = new Audio("/sounds/success.mp3");
    successSfx.volume = 0.4;
    setSuccessSound(successSfx);
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  const handleNavigate = (screen: string) => {
    setCurrentScreen(screen as Screen);
  };

  const handleSelectLesson = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    setCurrentScreen("lesson");
  };

  const handleSelectSurah = (surah: Surah) => {
    setSelectedSurah(surah);
    setCurrentScreen("surah");
  };

  const handleLessonComplete = () => {
    setCurrentScreen("lessons");
    setSelectedLesson(null);
  };

  return (
    <div style={{ width: '100vw', height: '100vh', position: 'relative', overflow: 'auto' }}>
      {currentScreen === "home" && (
        <Home onNavigate={handleNavigate} />
      )}
      
      {currentScreen === "lessons" && (
        <LessonList onNavigate={handleNavigate} onSelectLesson={handleSelectLesson} />
      )}
      
      {currentScreen === "lesson" && selectedLesson && (
        <LessonView 
          lesson={selectedLesson} 
          onNavigate={handleNavigate}
          onComplete={handleLessonComplete}
        />
      )}
      
      {currentScreen === "surahs" && (
        <SurahList onNavigate={handleNavigate} onSelectSurah={handleSelectSurah} />
      )}
      
      {currentScreen === "surah" && selectedSurah && (
        <SurahReader surah={selectedSurah} onNavigate={handleNavigate} />
      )}
      
      {currentScreen === "duas" && (
        <DuasList onNavigate={handleNavigate} />
      )}
      
      {currentScreen === "progress" && (
        <Progress onNavigate={handleNavigate} />
      )}
      
      {currentScreen === "settings" && (
        <Settings onNavigate={handleNavigate} />
      )}
    </div>
  );
}

export default App;
