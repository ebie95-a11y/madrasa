import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name"),
  isAdult: boolean("is_adult").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const surahs = pgTable("surahs", {
  id: serial("id").primaryKey(),
  number: integer("number").notNull().unique(),
  nameArabic: text("name_arabic").notNull(),
  nameEnglish: text("name_english").notNull(),
  nameTransliteration: text("name_transliteration").notNull(),
  versesCount: integer("verses_count").notNull(),
  revelationType: text("revelation_type").notNull(),
  difficulty: integer("difficulty").default(1),
  audioUrl: text("audio_url"),
});

export const verses = pgTable("verses", {
  id: serial("id").primaryKey(),
  surahId: integer("surah_id").notNull(),
  verseNumber: integer("verse_number").notNull(),
  textArabic: text("text_arabic").notNull(),
  textTransliteration: text("text_transliteration"),
  translation: text("translation"),
  audioUrl: text("audio_url"),
  tajweedRules: jsonb("tajweed_rules"),
});

export const lessons = pgTable("lessons", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  titleArabic: text("title_arabic"),
  description: text("description"),
  category: text("category").notNull(),
  orderIndex: integer("order_index").notNull(),
  content: jsonb("content"),
  surahId: integer("surah_id"),
  difficulty: integer("difficulty").default(1),
});

export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  lessonId: integer("lesson_id"),
  surahId: integer("surah_id"),
  verseId: integer("verse_id"),
  completed: boolean("completed").default(false),
  masteryLevel: integer("mastery_level").default(0),
  practiceCount: integer("practice_count").default(0),
  lastPracticed: timestamp("last_practiced"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  nameArabic: text("name_arabic"),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  requirement: jsonb("requirement"),
  points: integer("points").default(10),
});

export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: integer("achievement_id").notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  displayName: true,
  isAdult: true,
});

export const insertSurahSchema = createInsertSchema(surahs);
export const insertVerseSchema = createInsertSchema(verses);
export const insertLessonSchema = createInsertSchema(lessons);
export const insertProgressSchema = createInsertSchema(userProgress);
export const insertAchievementSchema = createInsertSchema(achievements);

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Surah = typeof surahs.$inferSelect;
export type Verse = typeof verses.$inferSelect;
export type Lesson = typeof lessons.$inferSelect;
export type UserProgress = typeof userProgress.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
